# Coding Prompt: Phishing Awareness Simulation Platform

Use this prompt to generate a fully functional, self-contained Phishing Awareness Simulation, Consent, and Report Generation web application.

---

## **Prompt Title: Comprehensive Phishing Awareness Simulation, Ethics, and Report Generator Platform**

### **Objective**
Build a local web application that serves as a **Phishing Awareness Simulation** tool. The application must allow an administrator to configure simulation campaigns, enforce and manage informed consent, generate harmless phishing emails and landing pages, track user interactions (clicks, form submissions, and reports) in real-time, present an interactive educational page showing security "red flags," and auto-generate a comprehensive project report (containing Introduction, Methodology, Results, and Preventive Measures) to fulfill academic/training deliverables.

---

### **Technical Stack**
*   **Backend**: Node.js with Express.js (lightweight, using in-memory storage or a simple local `db.json` file to keep track of campaign statistics).
*   **Frontend**: Vanilla HTML5, CSS3 (with clean, modern styling, transitions, and responsive layout), and Vanilla JavaScript.
*   **Charts**: Chart.js (loaded via CDN) for the admin dashboard.
*   **Project Structure**:
    *   `/server.js` - Express backend for logging tracking events (clicks, data submissions, reports) and serving pages.
    *   `/public/admin/` - Admin dashboard files (index.html, dashboard.js, style.css) including the report generator and screenshot helper.
    *   `/public/templates/` - Fake email templates and basic HTML/CSS login clones (e.g., Google, Microsoft, or Netflix).
    *   `/public/education/` - The training/feedback page showing red flags.
    *   `/public/consent/` - A participant portal to register informed consent before the simulation begins.

---

### **Key Features & Requirements**

#### **1. Ethics & Informed Consent Module (`/consent`)**
*   **Participant Portal**: A page where participants can read a brief description of the phishing awareness study and sign/submit an informed consent agreement (entering their email/name to be added to the whitelist).
*   **Ethical Verification**: The backend must verify that an email is in the consented/whitelisted database before tracking or serving simulated phishing emails.
*   **Ethics Statement**: Clearly present the ethical rules: no actual credentials stored, participants are informed beforehand that a simulation is happening within a set timeframe, and the purpose is purely educational.

#### **2. Admin Dashboard (`/admin`)**
*   **Real-time Analytics Dashboard**: Display key performance indicators (KPIs) in real-time:
    *   *Consented Participants / Total Emails Sent*
    *   *Click-Through Rate (CTR)*: Number of users who clicked the link in the email.
    *   *Submission Rate (SR)*: Number of users who submitted details on the landing page.
    *   *Report Rate (RR)*: Number of users who clicked the "Report Phishing" option.
*   **Visual Charts**: A line or bar chart showing events over time, and a doughnut chart showing the ratio of safe users vs. clicked vs. submitted.
*   **Campaign Manager**:
    *   Allow the admin to select a scenario template (e.g., "Microsoft Password Reset", "Urgent Google Verification").
    *   Generate a unique simulation tracking link for the campaign (e.g., `http://localhost:3000/track/click?campaignId=123`).
    *   Show a preview of the email template and provide an "HTML Copy" button to easily copy the email body.
*   **Activity Log**: A table showing real-time event logs with timestamps (e.g., `[14:32:10] User clicked email link`, `[14:33:05] User submitted credentials (Mocked)`). *Note: Ensure absolutely NO actual password or sensitive data is captured or logged; only log that a submission attempt occurred.*

#### **3. Email Templates & Delivery Copy**
*   Provide 3 distinct phishing templates inside the app:
    *   **Template A (Urgent Password Reset)**: Mimicking an IT department warning the user that their password expires in 2 hours.
    *   **Template B (Shared Document)**: Mimicking a Google Drive or OneDrive shared spreadsheet request.
    *   **Template C (Billing Warning)**: A generic subscription warning (Netflix/Spotify) requiring urgent card update.
*   Each template should contain visible but subtle red flags (e.g., sender email domain mismatch, urgent tone, spelling typos, suspicious link destination).
*   Include a "Report Phishing" button in the email footer to simulate a reporting system.

#### **4. Landing Page Mimics (Credential Harvester Simulation)**
*   A realistic but harmless replica of a standard login page (e.g., Microsoft or Google login).
*   **Behavior**:
    *   When the user inputs dummy credentials and clicks "Log In", intercept the event to send a POST request to `/track/submit` (with the campaign ID).
    *   **Crucial Security Rule**: Do NOT transmit or store the entered password. Only log the action of form submission.
    *   Immediately redirect the user to the **Educational Awareness Page**.

#### **5. Educational "Red Flags" Page (`/education`)**
*   This page is displayed immediately after a user falls for the simulation (clicks the link or submits dummy data).
*   **Design**: Modern, informative, and encouraging rather than punitive. Title: *"Wait! This was a Phishing Simulation."*
*   **Interactive Red Flag Guide**:
    *   Show interactive mockups of the fake email and landing page.
    *   Allow users to hover or click on highlighted zones (hotspots) to reveal the clues they missed:
        *   *Sender Address*: Pointing out `admin@microsoft-support-security.com` instead of `@microsoft.com`.
        *   *Urgency*: Explaining how attackers use fear/urgency to bypass logical thinking.
        *   *Suspicious URL*: Pointing out the actual URL bar showing `localhost` or an unrelated domain.
        *   *Generic Greeting*: Highlighting "Dear Customer" instead of the user's name.
*   **Takeaway Checklist**: A quick 3-step checklist of what to do when receiving suspicious emails in the future.

#### **6. Report Generator & Deliverables Helper**
*   **Exportable Report Page**: A feature to generate a formatted project report as an HTML document or a printable page with the following sections:
    *   **Introduction**: Overview of phishing threats and the importance of social engineering awareness.
    *   **Methodology**: Detailed explanation of the consent process, the phishing vector chosen, and the simulation parameters.
    *   **Results**: Dynamically populate tables and summary statistics of the campaign results (total sent, clicked, submitted, reported). Include placeholder sections for adding screenshots.
    *   **Lessons Learned**: A discussion of user behavior patterns and susceptibility factors.
    *   **Preventive Measures**: Technical and behavioral countermeasures to defend against real-world phishing.
*   **Screenshot Presentation mode**: A page layout helper that presents the fake email template, the fake login page, and the dashboard side-by-side in clean browser frames, making it extremely easy for the student/admin to take screenshots for their report.

---

### **Design Aesthetics**
*   **Admin Dashboard**: Clean dark-mode UI with a professional layout, glassmorphic cards, clear typography (e.g., Inter or Outfit), and vibrant accent colors (e.g., neon blue, emerald green, warning orange).
*   **Educational Page**: Clean light/dark toggle, accessible text sizing, intuitive hover tooltips, and green/red visual indicators highlighting secure vs. insecure features.

---

### **Implementation Steps**
1.  **Server Setup**: Configure Express to serve static files from `/public` and create endpoint routes for tracking (`/track/click`, `/track/submit`, `/track/report`).
2.  **Consent System**: Use a simple local JSON file to save whitelisted (consented) emails.
3.  **UI Construction**: Create the layout for the admin panel and link Chart.js to the analytics endpoint via a simple polling fetch request.
4.  **Cloning / Landing Page creation**: Write clean, basic login forms that capture inputs.
5.  **Interactive Walkthrough**: Implement the educational review screen using CSS tooltips or JS modals over the email/web screenshots.
6.  **Report Exporter**: Create a report layout file that queries the local JSON file for current campaign metrics and formats them into a clean report format ready for exporting.
