/* Phishing Awareness Simulation Platform - Shared JS Library */

// Initialize default state in localStorage if not exists
const DEFAULT_STATE = {
  whitelist: [
    { email: "john.doe@academic.edu", name: "John Doe", consentedAt: new Date().toISOString() }
  ],
  campaigns: [
    {
      id: "c1",
      name: "Microsoft Password Reset Expiry",
      targetEmail: "john.doe@academic.edu",
      template: "microsoft",
      clicks: 0,
      submissions: 0,
      reports: 0,
      status: "Active"
    },
    {
      id: "c2",
      name: "Google Drive Collaboration Invite",
      targetEmail: "",
      template: "google",
      clicks: 0,
      submissions: 0,
      reports: 0,
      status: "Draft"
    },
    {
      id: "c3",
      name: "Netflix Outstanding Billing Action Required",
      targetEmail: "",
      template: "netflix",
      clicks: 0,
      submissions: 0,
      reports: 0,
      status: "Draft"
    }
  ],
  logs: [
    { timestamp: new Date().toISOString(), message: "System initialized with John Doe whitelisted." }
  ]
};

function getAppState() {
  const stateStr = localStorage.getItem("phish_simulation_state");
  if (!stateStr) {
    localStorage.setItem("phish_simulation_state", JSON.stringify(DEFAULT_STATE));
    return DEFAULT_STATE;
  }
  try {
    return JSON.parse(stateStr);
  } catch (e) {
    return DEFAULT_STATE;
  }
}

function saveAppState(state) {
  localStorage.setItem("phish_simulation_state", JSON.stringify(state));
}

function logSimulationEvent(message) {
  const state = getAppState();
  const timestamp = new Date().toISOString();
  state.logs.unshift({ timestamp, message });
  // Keep logs at a reasonable limit
  if (state.logs.length > 150) {
    state.logs.pop();
  }
  saveAppState(state);
}

// Check email in Whitelist
function isEmailWhitelisted(email) {
  if (!email) return false;
  const state = getAppState();
  return state.whitelist.some(item => item.email.toLowerCase() === email.trim().toLowerCase());
}

// Add user to whitelist
function addEmailToWhitelist(email, name) {
  if (!email || !name) return false;
  const state = getAppState();
  const emailNorm = email.trim().toLowerCase();

  if (state.whitelist.some(item => item.email.toLowerCase() === emailNorm)) {
    return false; // Already whitelisted
  }

  state.whitelist.push({
    email: emailNorm,
    name: name.trim(),
    consentedAt: new Date().toISOString()
  });

  saveAppState(state);
  logSimulationEvent(`Whitelisted participant: ${name} (${emailNorm})`);
  return true;
}

// Add stats tracking
function recordSimulationMetric(campaignId, metric) {
  const state = getAppState();
  const campaign = state.campaigns.find(c => c.id === campaignId);
  if (campaign) {
    if (metric === "click") {
      campaign.clicks++;
      logSimulationEvent(`Campaign [${campaign.name}] - Target clicked the mock phishing link.`);
    } else if (metric === "submit") {
      campaign.submissions++;
      logSimulationEvent(`Campaign [${campaign.name}] - Target attempted mock login form submission.`);
    } else if (metric === "report") {
      campaign.reports++;
      logSimulationEvent(`Campaign [${campaign.name}] - Target reported the email as phishing.`);
    }
    saveAppState(state);
  }
}

// Format Date string
function formatLogDate(dateStr) {
  const date = new Date(dateStr);
  const pad = (num) => String(num).padStart(2, '0');
  return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

// Color state switcher
document.addEventListener("DOMContentLoaded", () => {
  const themeToggle = document.getElementById("checkbox");
  if (themeToggle) {
    // Check saved theme
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "light") {
      document.body.classList.add("light-mode");
      themeToggle.checked = true;
    }

    themeToggle.addEventListener("change", () => {
      if (themeToggle.checked) {
        document.body.classList.add("light-mode");
        localStorage.setItem("theme", "light");
      } else {
        document.body.classList.remove("light-mode");
        localStorage.setItem("theme", "dark");
      }
    });
  }
});
