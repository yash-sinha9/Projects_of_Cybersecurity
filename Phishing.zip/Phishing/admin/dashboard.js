/* Phishing Awareness Simulation Platform - Admin Dashboard controller */

let barChart = null;
let doughnutChart = null;

function switchTab(tabName) {
  // Hide all tab panes
  document.querySelectorAll(".tab-pane").forEach(pane => {
    pane.classList.remove("active");
  });
  // Deactivate all sidebar buttons
  document.querySelectorAll(".sidebar-btn").forEach(btn => {
    btn.classList.remove("active");
  });

  // Activate targets
  document.getElementById(`tab-${tabName}`).classList.add("active");
  const actBtn = document.getElementById(`btn-tab-${tabName}`);
  if (actBtn) actBtn.classList.add("active");

  if (tabName === "dash") {
    refreshDashboard();
  } else if (tabName === "campaign") {
    populateCampaignConfigForm();
  } else if (tabName === "report") {
    buildAcademicReport();
  }
}

function refreshDashboard() {
  const state = getAppState();

  // Populate KPIs
  const totalWhitelisted = state.whitelist.length;
  document.getElementById("kpi-whitelisted").innerText = totalWhitelisted;

  // Aggregate Metrics
  let totalClicks = 0;
  let totalSubmissions = 0;
  let totalReports = 0;

  state.campaigns.forEach(c => {
    totalClicks += c.clicks;
    totalSubmissions += c.submissions;
    totalReports += c.reports;
  });

  // Calculated Rates
  // Note: we base denominators on click activities or sends to mock realistic percentages
  const simulatedSends = Math.max(totalWhitelisted, 1);
  const ctr = Math.round((totalClicks / simulatedSends) * 100);
  const sr = Math.round((totalSubmissions / simulatedSends) * 100);
  const rr = Math.round((totalReports / simulatedSends) * 100);

  document.getElementById("kpi-ctr").innerText = `${ctr}%`;
  document.getElementById("kpi-clicks-sub").innerText = `${totalClicks} clicks recorded`;

  document.getElementById("kpi-sr").innerText = `${sr}%`;
  document.getElementById("kpi-submits-sub").innerText = `${totalSubmissions} submissions recorded`;

  document.getElementById("kpi-rr").innerText = `${rr}%`;
  document.getElementById("kpi-reports-sub").innerText = `${totalReports} reported safe`;

  // Screenshot helper card sync
  const ssCtr = document.getElementById("ss-ctr-show");
  const ssSr = document.getElementById("ss-sr-show");
  if (ssCtr) ssCtr.innerText = `${ctr}%`;
  if (ssSr) ssSr.innerText = `${sr}%`;

  // Refresh Charts
  renderChartData(state, totalClicks, totalSubmissions, totalReports, simulatedSends);

  // Populate Event Log Table
  const logListEl = document.getElementById("activity-log-list");
  logListEl.innerHTML = "";
  if (state.logs.length === 0) {
    logListEl.innerHTML = `<li class="log-item" style="color:var(--text-secondary);">[LOG] No simulation events recorded yet.</li>`;
  } else {
    state.logs.forEach(log => {
      const li = document.createElement("li");
      li.className = "log-item";
      li.innerHTML = `<span class="log-time">[${formatLogDate(log.timestamp)}]</span> <span>${log.message}</span>`;
      logListEl.appendChild(li);
    });
  }

  // Populate Whitelist Table
  const tableBody = document.getElementById("whitelist-table-body");
  tableBody.innerHTML = "";
  if (state.whitelist.length === 0) {
    tableBody.innerHTML = `<tr><td colspan="2" style="text-align:center; color:var(--text-secondary);">No participants whitelisted yet.</td></tr>`;
  } else {
    state.whitelist.forEach(item => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><strong>${item.name}</strong></td>
        <td><code>${item.email}</code></td>
      `;
      tableBody.appendChild(tr);
    });
  }
}

function renderChartData(state, clicks, submits, reports, sends) {
  const isLight = document.body.classList.contains("light-mode");
  const textClr = isLight ? "#111827" : "#f3f4f6";
  const gridClr = isLight ? "rgba(0,0,0,0.06)" : "rgba(255,255,255,0.06)";

  const labels = state.campaigns.map(c => c.name.split(" ")[0]); // Get abbreviation
  const clicksData = state.campaigns.map(c => c.clicks);
  const submitsData = state.campaigns.map(c => c.submissions);
  const reportsData = state.campaigns.map(c => c.reports);

  // 1. Bar Chart Setup
  const ctxBar = document.getElementById("mainBarChart").getContext("2d");
  if (barChart) {
    barChart.destroy();
  }

  barChart = new Chart(ctxBar, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [
        {
          label: "Clicks",
          data: clicksData,
          backgroundColor: "#3b82f6", // Blue
          borderRadius: 4
        },
        {
          label: "Submissions",
          data: submitsData,
          backgroundColor: "#ef4444", // Rose
          borderRadius: 4
        },
        {
          label: "Reports",
          data: reportsData,
          backgroundColor: "#10b981", // Emerald
          borderRadius: 4
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: { color: textClr }
        }
      },
      scales: {
        x: {
          grid: { color: gridClr },
          ticks: { color: textClr }
        },
        y: {
          grid: { color: gridClr },
          ticks: { color: textClr, stepSize: 1 }
        }
      }
    }
  });

  // 2. Doughnut Chart Setup
  const ctxDoughnut = document.getElementById("ratioDoughnutChart").getContext("2d");
  if (doughnutChart) {
    doughnutChart.destroy();
  }

  // Calculate safe users as whitelisted - clicked
  const safeCount = Math.max(0, sends - clicks);

  doughnutChart = new Chart(ctxDoughnut, {
    type: "doughnut",
    data: {
      labels: ["Safe Actions", "Clicks", "Submissions"],
      datasets: [{
        data: [safeCount, clicks, submits],
        backgroundColor: ["#10b981", "#f59e0b", "#ef4444"],
        borderWidth: 1,
        borderColor: isLight ? "#ffffff" : "#161e2e"
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: "bottom",
          labels: { color: textClr }
        }
      }
    }
  });
}

function populateCampaignConfigForm() {
  const state = getAppState();
  const select = document.getElementById("campaign-email-select");
  select.innerHTML = "";

  if (state.whitelist.length === 0) {
    const opt = document.createElement("option");
    opt.value = "";
    opt.innerText = "-- No whitelisted users found --";
    select.appendChild(opt);
  } else {
    state.whitelist.forEach(item => {
      const opt = document.createElement("option");
      opt.value = item.email;
      opt.innerText = `${item.name} (${item.email})`;
      select.appendChild(opt);
    });
  }
}

// Handle campaign links creator submit
document.getElementById("campaign-creator-form").addEventListener("submit", (e) => {
  e.preventDefault();

  const scenarioVal = document.getElementById("campaign-scenario").value;
  const targetEmail = document.getElementById("campaign-email-select").value;

  if (!targetEmail) {
    alert("Please select a whitelisted recipient first.");
    return;
  }

  const state = getAppState();

  // Update campaign data
  const campaign = state.campaigns.find(c => c.template === scenarioVal);
  if (campaign) {
    campaign.targetEmail = targetEmail;
    campaign.status = "Active";

    // Generate tracking target URL link relative to current folder path
    const loc = window.location.href;
    const baseDir = loc.substring(0, loc.lastIndexOf('/'));
    const linkStr = `${baseDir}/email_preview.html?campaignId=${campaign.id}&targetEmail=${encodeURIComponent(targetEmail)}`;

    document.getElementById("campaign-track-link").value = linkStr;

    const launchBtn = document.getElementById("launch-sim-link");
    launchBtn.href = linkStr;

    document.getElementById("campaign-result-card").style.display = "block";

    saveAppState(state);
    logSimulationEvent(`Generated tracking parameters link targeting ${targetEmail} under campaign [${campaign.name}]`);
  }
});

function copyCampaignText(elementId) {
  const copyText = document.getElementById(elementId);
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(copyText.value);
  alert("Simulated Link copied to clipboard!");
}

function buildAcademicReport() {
  const state = getAppState();
  const reportBody = document.getElementById("report-table-body");
  reportBody.innerHTML = "";

  let totalClicks = 0;
  let totalSubmissions = 0;
  let totalReports = 0;
  let totalSends = 0;

  state.campaigns.forEach(c => {
    const sendsCount = c.targetEmail ? 1 : 0;
    totalSends += sendsCount;
    totalClicks += c.clicks;
    totalSubmissions += c.submissions;
    totalReports += c.reports;

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td style="text-align:left;"><strong>${c.name}</strong></td>
      <td>${sendsCount}</td>
      <td>${c.clicks}</td>
      <td>${c.submissions}</td>
      <td>${c.reports}</td>
    `;
    reportBody.appendChild(tr);
  });

  const denominator = Math.max(totalSends, 1);
  const ctr = Math.round((totalClicks / denominator) * 100);
  const sr = Math.round((totalSubmissions / denominator) * 100);
  const rr = Math.round((totalReports / denominator) * 100);

  document.getElementById("report-ctr-calc").innerText = `${ctr}%`;
  document.getElementById("report-sr-calc").innerText = `${sr}%`;
  document.getElementById("report-rr-calc").innerText = `${rr}%`;
}

function triggerResetSimulation() {
  if (confirm("Warning: This will clear all recorded statistics, logs, and your whitelisted user base. Reset simulation database state?")) {
    localStorage.removeItem("phish_simulation_state");
    alert("Simulation database has been reset to defaults.");
    refreshDashboard();
  }
}

// Initial dashboard load
document.addEventListener("DOMContentLoaded", () => {
  refreshDashboard();

  // Redraw charts when theme changes
  const themeToggle = document.getElementById("checkbox");
  if (themeToggle) {
    themeToggle.addEventListener("change", () => {
      setTimeout(() => {
        refreshDashboard();
      }, 100);
    });
  }
});
